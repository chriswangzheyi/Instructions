package com.wzy.map;

import com.alibaba.fastjson.JSONObject;
import com.wzy.entity.AdvertisingLiuliangEntity;
import com.wzy.entity.LiuliangEntity;
import com.wzy.input.ScanPageLog;
import com.wzy.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.MapFunction;

public class AdvertisingLiuLiangMap implements MapFunction<String, AdvertisingLiuliangEntity> {


    @Override
    public AdvertisingLiuliangEntity map(String s) throws Exception {
        if(StringUtils.isNotBlank(s)){
            ScanPageLog scanPageLog = JSONObject.parseObject(s,ScanPageLog.class);
            long userid = scanPageLog.getUserid();
            long visitTime = scanPageLog.getVisitTime();
            long adverId = scanPageLog.getAdverId();
            String visitTimeDay = DateUtil.tranferDate(visitTime,"yyyyMMdd");
            long numbers = 1l;
            String groupField = "adverstliuliang=="+userid+"=="+adverId+"=="+visitTimeDay;

            AdvertisingLiuliangEntity advertisingLiuliangEntity = new AdvertisingLiuliangEntity();
            advertisingLiuliangEntity.setUserid(userid);
            advertisingLiuliangEntity.setTimeinfo(visitTime);
            advertisingLiuliangEntity.setTimeString(visitTimeDay);
            advertisingLiuliangEntity.setAdverId(adverId);
            advertisingLiuliangEntity.setNumbers(numbers);
            advertisingLiuliangEntity.setGroupField(groupField);
            return advertisingLiuliangEntity;

        }
        return null;
    }
}
