package com.wzy.analy;

import com.youfan.entity.LiuliangEntity;
import com.youfan.entity.OrderInfoEntity;
import com.youfan.map.OrderPayStatusMap;
import com.youfan.reduce.OrderPayStatusReduce;
import com.youfan.reduce.OrderPayStatusTotalReduce;
import com.youfan.sink.LiuLiangTotallSink;
import com.youfan.sink.OrderInfoUserDetailSink;
import com.youfan.sink.OrderPayStatusTotallSink;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class OrderPayAnaly {
    public static void main(String[] args) {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "192.168.37.137:9092");
        properties.setProperty("group.id", "youfan");
        //构建FlinkKafkaConsumer
        FlinkKafkaConsumer<String> myConsumer = new FlinkKafkaConsumer<String>("youfanorder", new SimpleStringSchema(), properties);
        //        //指定偏移量
        myConsumer.setStartFromLatest();

        final DataStream<String> stream = env
                .addSource(myConsumer);

        env.enableCheckpointing(5000);
        DataStream<OrderInfoEntity> map = stream.map(new OrderPayStatusMap());
        DataStream<OrderInfoEntity> reduce = map.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new OrderPayStatusReduce());
        DataStream<OrderInfoEntity> totalReduce = reduce.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new OrderPayStatusTotalReduce());
        reduce.addSink(new OrderInfoUserDetailSink());
        totalReduce.addSink(new OrderPayStatusTotallSink());
        try {
            env.execute("OrderPayAnaly");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
