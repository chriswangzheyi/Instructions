package com.wzy.map;

import com.alibaba.fastjson.JSONObject;
import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserBehavEntity;
import com.wzy.input.ScanPageLog;
import com.wzy.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.MapFunction;

public class UserBehavMap implements MapFunction<String, UserBehavEntity> {


    @Override
    public UserBehavEntity map(String s) throws Exception {
        if(StringUtils.isNotBlank(s)){
            ScanPageLog scanPageLog = JSONObject.parseObject(s,ScanPageLog.class);
            long userid = scanPageLog.getUserid();


            long visitTime = scanPageLog.getVisitTime();
            int timeint = -1;
            /**
             * //0-5 1 夜猫子 //5-8 2 早起的人 //8-12  3 上班 并且上午比较闲的人
             *     // 12-6  4 上班 并且下午比较闲的人 // 6-10  5 上班比较忙 下班才有时间
             *     //10-12  6 晚睡的人
             */
            int timehh = Integer.valueOf(DateUtil.tranferDate(visitTime,"hh"));
            if(timehh>=0 && timehh<5){
                timeint = 1;
            }else if (timehh >= 5 && timehh<8){
                timeint = 2;
            }else if (timehh >= 8 && timehh<12){
                timeint = 3;
            }else if (timehh >= 12 && timehh<18){
                timeint = 4;
            }else if (timehh >= 18 && timehh<22){
                timeint = 5;
            }
            else if (timehh >= 22 && timehh<24){
                timeint = 6;
            }
            String visitTimeDay = DateUtil.tranferDate(visitTime,"yyyyMMdd");
            long numbers = 1l;
            String groupField = "userBehavtime=="+userid+"=="+timeint+"=="+visitTimeDay;

            UserBehavEntity userBehavEntity = new UserBehavEntity();
            userBehavEntity.setUserid(userid);
            userBehavEntity.setTimeinfo(visitTime);
            userBehavEntity.setTimeString(visitTimeDay);
            userBehavEntity.setTimeinType(timeint);
            userBehavEntity.setNumbers(numbers);
            userBehavEntity.setGroupField(groupField);
            return userBehavEntity;

        }
        return null;
    }
}
