package com.wzy.reduce;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserBehavEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class UserBeTimeTotalReduce implements ReduceFunction<UserBehavEntity> {
    @Override
    public UserBehavEntity reduce(UserBehavEntity userBehavEntity, UserBehavEntity t1) throws Exception {
        int timeinType = userBehavEntity.getTimeinType();
        long nubmers = userBehavEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = userBehavEntity.getTimeString();
        UserBehavEntity userBehavEntityResult = new UserBehavEntity();
        userBehavEntityResult.setTimeinType(timeinType);
        userBehavEntityResult.setNumbers(nubmers+t1numbers);
        userBehavEntityResult.setTimeString(timeString);
        return userBehavEntityResult;
    }
}
