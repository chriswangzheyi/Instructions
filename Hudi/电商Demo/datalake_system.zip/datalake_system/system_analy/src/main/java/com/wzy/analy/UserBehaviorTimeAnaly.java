package com.wzy.analy;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserBehavEntity;
import com.wzy.map.LiuLiangMap;
import com.wzy.map.UserBehavMap;
import com.wzy.reduce.LiuLiangReduce;
import com.wzy.reduce.LiuLiangTotalReduce;
import com.wzy.reduce.UserBeTimeTotalReduce;
import com.wzy.reduce.UserBehaviorTimeReduce;
import com.wzy.sink.LiuLiangTotallSink;
import com.wzy.sink.LiuLiangUserDetailSink;
import com.wzy.sink.UserBeTimeTotallSink;
import com.wzy.sink.UserBeTimeUserDetailSink;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class UserBehaviorTimeAnaly {
    public static void main(String[] args) {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "192.168.37.137:9092");
        properties.setProperty("group.id", "youfan");
        //构建FlinkKafkaConsumer
        FlinkKafkaConsumer<String> myConsumer = new FlinkKafkaConsumer<String>("scanpage", new SimpleStringSchema(), properties);
        //        //指定偏移量
        myConsumer.setStartFromLatest();

        final DataStream<String> stream = env
                .addSource(myConsumer);

        env.enableCheckpointing(5000);
        DataStream<UserBehavEntity> map = stream.map(new UserBehavMap());
        DataStream<UserBehavEntity> reduce = map.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new UserBehaviorTimeReduce());
        DataStream<UserBehavEntity> totalReduce = reduce.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new UserBeTimeTotalReduce());
        reduce.addSink(new UserBeTimeUserDetailSink());
        totalReduce.addSink(new UserBeTimeTotallSink());
        try {
            env.execute("UserBehaviorTimeAnaly");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
