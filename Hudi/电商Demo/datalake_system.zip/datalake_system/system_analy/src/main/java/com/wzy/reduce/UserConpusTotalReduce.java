package com.wzy.reduce;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserConpusEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class UserConpusTotalReduce implements ReduceFunction<UserConpusEntity> {
    @Override
    public UserConpusEntity reduce(UserConpusEntity userConpusEntity, UserConpusEntity t1) throws Exception {
        long conpusId = userConpusEntity.getConpusId();
        long nubmers = userConpusEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = userConpusEntity.getTimeString();
        UserConpusEntity resultUserConpusEntity = new UserConpusEntity();
        resultUserConpusEntity.setConpusId(conpusId);
        resultUserConpusEntity.setNumbers(nubmers+t1numbers);
        resultUserConpusEntity.setTimeString(timeString);
        return resultUserConpusEntity;
    }
}
