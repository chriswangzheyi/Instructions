package com.wzy.sink;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserConpusEntity;
import com.wzy.util.ClickhouseUtils;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import java.util.HashMap;
import java.util.Map;

public class UserConpusTotallSink implements SinkFunction<UserConpusEntity> {

    @Override
    public void invoke(UserConpusEntity value) throws Exception {
        Map<String,Object> dataMap = new HashMap<String,Object>();
        String timeString = value.getTimeString();//
        long numbers = value.getNumbers();
        long conpusId = value.getConpusId();
        dataMap.put("timeString",timeString);
        dataMap.put("conpusId",conpusId);
        dataMap.put("numbers",numbers);
        ClickhouseUtils.insertData(dataMap);
    }
}
