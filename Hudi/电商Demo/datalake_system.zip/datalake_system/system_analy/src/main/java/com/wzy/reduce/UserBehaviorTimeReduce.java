package com.wzy.reduce;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserBehavEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class UserBehaviorTimeReduce implements ReduceFunction<UserBehavEntity> {
    @Override
    public UserBehavEntity reduce(UserBehavEntity userBehavEntity, UserBehavEntity t1) throws Exception {
        long userid = userBehavEntity.getUserid();
        int timeinType = userBehavEntity.getTimeinType();
        long nubmers = userBehavEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = userBehavEntity.getTimeString();
        UserBehavEntity resultUserBehavEntity = new  UserBehavEntity();
        resultUserBehavEntity.setUserid(userid);
        resultUserBehavEntity.setTimeinType(timeinType);
        resultUserBehavEntity.setNumbers(nubmers+t1numbers);
        resultUserBehavEntity.setTimeString(timeString);
        String groupField = "userBehavtime=="+timeinType+"=="+timeString;;
        resultUserBehavEntity.setGroupField(groupField);
        return resultUserBehavEntity;
    }
}
