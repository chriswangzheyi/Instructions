package com.wzy.sink;

import com.alibaba.fastjson.JSONObject;
import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserConpusEntity;
import com.wzy.util.CommonUtils;
import com.wzy.util.KafkaUtils;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

public class UserConpusUserDetailSink implements SinkFunction<UserConpusEntity> {

    @Override
    public void invoke(UserConpusEntity value) throws Exception {
        String timeString = value.getTimeString();
        value.setId(CommonUtils.getId());
        String year = timeString.substring(0,4);
        String month = timeString.substring(4,6);
        String day = timeString.substring(6,timeString.length());
        value.setYear(year);
        value.setMonth(month);
        value.setDay(day);
        String json = JSONObject.toJSONString(value);
        KafkaUtils.sendData("userConpusdetail",json);
    }
}
