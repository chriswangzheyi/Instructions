package com.wzy.sink;

import com.wzy.entity.LiuliangEntity;
import com.wzy.util.ClickhouseUtils;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import java.util.HashMap;
import java.util.Map;

public class LiuLiangTotallSink implements SinkFunction<LiuliangEntity> {

    @Override
    public void invoke(LiuliangEntity value) throws Exception {
        Map<String,Object> dataMap = new HashMap<String,Object>();
        String timeString = value.getTimeString();//
        long numbers = value.getNumbers();
        int deviceType = value.getDeviceType();
        dataMap.put("timeString",timeString);
        dataMap.put("deviceType",deviceType);
        dataMap.put("numbers",numbers);
        //发送消息到CK
        ClickhouseUtils.insertData(dataMap);
    }
}
