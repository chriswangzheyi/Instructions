package com.wzy.analy;

import com.wzy.entity.UserBehavEntity;
import com.wzy.entity.UserConpusEntity;
import com.wzy.map.UserBehavMap;
import com.wzy.map.UserConpusMap;
import com.wzy.reduce.UserBeTimeTotalReduce;
import com.wzy.reduce.UserBehaviorTimeReduce;
import com.wzy.reduce.UserConpusReduce;
import com.wzy.reduce.UserConpusTotalReduce;
import com.wzy.sink.UserBeTimeTotallSink;
import com.wzy.sink.UserBeTimeUserDetailSink;
import com.wzy.sink.UserConpusTotallSink;
import com.wzy.sink.UserConpusUserDetailSink;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class UserConpusAnaly {
    public static void main(String[] args) {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "192.168.37.137:9092");
        properties.setProperty("group.id", "youfan");
        //构建FlinkKafkaConsumer
        FlinkKafkaConsumer<String> myConsumer = new FlinkKafkaConsumer<String>("youfanorder", new SimpleStringSchema(), properties);
        //        //指定偏移量
        myConsumer.setStartFromLatest();

        final DataStream<String> stream = env
                .addSource(myConsumer);

        env.enableCheckpointing(5000);
        DataStream<UserConpusEntity> map = stream.map(new UserConpusMap());
        DataStream<UserConpusEntity> reduce = map.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new UserConpusReduce());
        DataStream<UserConpusEntity> totalReduce = reduce.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new UserConpusTotalReduce());
        reduce.addSink(new UserConpusUserDetailSink());
        totalReduce.addSink(new UserConpusTotallSink());
        try {
            env.execute("UserConpusAnaly");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
