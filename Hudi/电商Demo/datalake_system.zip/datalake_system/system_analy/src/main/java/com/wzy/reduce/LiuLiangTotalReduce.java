package com.wzy.reduce;

import com.wzy.entity.LiuliangEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class LiuLiangTotalReduce implements ReduceFunction<LiuliangEntity> {
    @Override
    public LiuliangEntity reduce(LiuliangEntity liuliangEntity, LiuliangEntity t1) throws Exception {
        int deviceType = liuliangEntity.getDeviceType();
        long nubmers = liuliangEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = liuliangEntity.getTimeString();
        LiuliangEntity resultLiuliangEntity = new LiuliangEntity();
        resultLiuliangEntity.setDeviceType(deviceType);
        resultLiuliangEntity.setNumbers(nubmers+t1numbers);
        resultLiuliangEntity.setTimeString(timeString);
        return resultLiuliangEntity;
    }
}
