package com.wzy.sink;

import com.wzy.entity.AdvertisingLiuliangEntity;
import com.wzy.entity.LiuliangEntity;
import com.wzy.util.ClickhouseUtils;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import java.util.HashMap;
import java.util.Map;

public class AdversingLiuLiangTotallSink implements SinkFunction<AdvertisingLiuliangEntity> {

    @Override
    public void invoke(AdvertisingLiuliangEntity value) throws Exception {
        Map<String,Object> dataMap = new HashMap<String,Object>();
        String timeString = value.getTimeString();//
        long numbers = value.getNumbers();
        long usernumbers = value.getUserNumbers();
        long adverId = value.getAdverId();
        dataMap.put("timeString",timeString);
        dataMap.put("adverId",adverId);
        dataMap.put("numbers",numbers);
        dataMap.put("usernumbers",usernumbers);
        ClickhouseUtils.insertData(dataMap);
    }
}
