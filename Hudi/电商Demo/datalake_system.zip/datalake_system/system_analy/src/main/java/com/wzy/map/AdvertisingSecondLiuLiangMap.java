package com.wzy.map;

import com.alibaba.fastjson.JSONObject;
import com.wzy.entity.AdvertisingLiuliangEntity;
import com.wzy.input.ScanPageLog;
import com.wzy.util.CommonUtils;
import com.wzy.util.DateUtil;
import com.wzy.util.KafkaUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.MapFunction;

public class AdvertisingSecondLiuLiangMap implements MapFunction<AdvertisingLiuliangEntity, AdvertisingLiuliangEntity> {


    @Override
    public AdvertisingLiuliangEntity map(AdvertisingLiuliangEntity advertisingLiuliangEntity) throws Exception {
        AdvertisingLiuliangEntity advertisingLiuliangEntityResutl = new AdvertisingLiuliangEntity();
        long userId = advertisingLiuliangEntity.getUserid();
        long nubmers = advertisingLiuliangEntity.getNumbers();
        String timeString = advertisingLiuliangEntity.getTimeString();
        long adverId = advertisingLiuliangEntity.getAdverId();

        advertisingLiuliangEntity.setId(CommonUtils.getId());
        String year = timeString.substring(0,4);
        String month = timeString.substring(4,6);
        String day = timeString.substring(6,timeString.length());
        advertisingLiuliangEntity.setYear(year);
        advertisingLiuliangEntity.setMonth(month);
        advertisingLiuliangEntity.setDay(day);
        String json = JSONObject.toJSONString(advertisingLiuliangEntity);
        KafkaUtils.sendData("adversterliuliangUserdetail",json);



        advertisingLiuliangEntityResutl.setTimeString(timeString);
        advertisingLiuliangEntityResutl.setAdverId(adverId);
        advertisingLiuliangEntityResutl.setNumbers(nubmers);
        advertisingLiuliangEntityResutl.setUserNumbers(1l);
        String groupField = "adverstliuliang"+"=="+adverId+"=="+timeString;
        advertisingLiuliangEntityResutl.setGroupField(groupField);
        return advertisingLiuliangEntityResutl;
    }
}
