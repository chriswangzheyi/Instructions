package com.wzy.map;

import com.alibaba.fastjson.JSONObject;
import com.wzy.entity.LiuliangEntity;
import com.wzy.input.ScanPageLog;
import com.wzy.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.MapFunction;

//完成解析
public class LiuLiangMap implements MapFunction<String, LiuliangEntity> {

    @Override
    public LiuliangEntity map(String s) throws Exception {
        if(StringUtils.isNotBlank(s)){
            ScanPageLog scanPageLog = JSONObject.parseObject(s,ScanPageLog.class);
            long userid = scanPageLog.getUserid();
            long visitTime = scanPageLog.getVisitTime();
            int divceType = scanPageLog.getDivceType();
            String visitTimeDay = DateUtil.tranferDate(visitTime,"yyyyMMdd");
            long numbers = 1l;
            String groupField = "liuliang=="+userid+"=="+divceType+"=="+visitTimeDay;

            LiuliangEntity liuliangEntity = new LiuliangEntity();
            liuliangEntity.setUserid(userid);
            liuliangEntity.setTimeinfo(visitTime);
            liuliangEntity.setTimeString(visitTimeDay);
            liuliangEntity.setDeviceType(divceType);
            liuliangEntity.setNumbers(numbers);
            liuliangEntity.setGroupField(groupField);
            return liuliangEntity;

        }
        return null;
    }
}
