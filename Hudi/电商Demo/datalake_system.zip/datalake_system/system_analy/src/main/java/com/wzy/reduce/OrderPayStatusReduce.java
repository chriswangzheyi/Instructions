package com.wzy.reduce;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.OrderInfoEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class OrderPayStatusReduce implements ReduceFunction<OrderInfoEntity> {
    @Override
    public OrderInfoEntity reduce(OrderInfoEntity orderInfoEntity, OrderInfoEntity t1) throws Exception {
        long userid = orderInfoEntity.getUserid();
        int status = orderInfoEntity.getStatus();
        long nubmers = orderInfoEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = orderInfoEntity.getTimeString();
        OrderInfoEntity resultOrderInfoEntity = new OrderInfoEntity();
        resultOrderInfoEntity.setUserid(userid);
        resultOrderInfoEntity.setStatus(status);
        resultOrderInfoEntity.setNumbers(nubmers+t1numbers);
        resultOrderInfoEntity.setTimeString(timeString);
        String groupField = "orderpaystatus"+"=="+status+"=="+timeString;
        resultOrderInfoEntity.setGroupField(groupField);
        return resultOrderInfoEntity;
    }
}
