package com.wzy.reduce;

import com.wzy.entity.LiuliangEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class LiuLiangReduce implements ReduceFunction<LiuliangEntity> {

    @Override
    public LiuliangEntity reduce(LiuliangEntity liuliangEntity, LiuliangEntity t1) throws Exception {
        long userid = liuliangEntity.getUserid();
        int deviceType = liuliangEntity.getDeviceType();
        long numbers = liuliangEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = liuliangEntity.getTimeString();

        //聚合后的内容
        LiuliangEntity resultLiuliangEntity = new LiuliangEntity();
        resultLiuliangEntity.setUserid(userid);
        resultLiuliangEntity.setDeviceType(deviceType);
        resultLiuliangEntity.setNumbers(numbers+t1numbers); //做了加法
        resultLiuliangEntity.setTimeString(timeString);
        String groupField = "liuliang"+"=="+deviceType+"=="+timeString;
        resultLiuliangEntity.setGroupField(groupField);
        return resultLiuliangEntity;
    }
}
