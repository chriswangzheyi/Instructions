package com.wzy.map;

import com.alibaba.fastjson.JSONObject;
import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.OrderInfoEntity;
import com.wzy.input.ScanPageLog;
import com.wzy.input.Order;
import com.wzy.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.MapFunction;

public class OrderPayStatusMap implements MapFunction<String, OrderInfoEntity> {


    @Override
    public OrderInfoEntity map(String s) throws Exception {
        if(StringUtils.isNotBlank(s)){
            Order youfanOrder = JSONObject.parseObject(s, Order.class);
            long userid = youfanOrder.getUserid();
            long visitTime = youfanOrder.getCreateTime().getTime();
            int status = youfanOrder.getOrderstatus();
            String visitTimeDay = DateUtil.tranferDate(visitTime,"yyyyMMdd");
            long numbers = 1l;
            String groupField = "liuliang=="+userid+"=="+status+"=="+visitTimeDay;

            OrderInfoEntity orderInfoEntity = new OrderInfoEntity();
            orderInfoEntity.setUserid(userid);
            orderInfoEntity.setTimeinfo(visitTime);
            orderInfoEntity.setTimeString(visitTimeDay);
            orderInfoEntity.setStatus(status);
            orderInfoEntity.setNumbers(numbers);
            orderInfoEntity.setGroupField(groupField);
            return orderInfoEntity;

        }
        return null;
    }
}
