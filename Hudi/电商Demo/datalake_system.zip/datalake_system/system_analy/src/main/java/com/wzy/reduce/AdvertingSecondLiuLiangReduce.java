package com.wzy.reduce;

import com.wzy.entity.AdvertisingLiuliangEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class AdvertingSecondLiuLiangReduce implements ReduceFunction<AdvertisingLiuliangEntity> {
    @Override
    public AdvertisingLiuliangEntity reduce(AdvertisingLiuliangEntity advertisingLiuliangEntity, AdvertisingLiuliangEntity t1) throws Exception {
        long adverId = advertisingLiuliangEntity.getAdverId();
        long nubmers = advertisingLiuliangEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = advertisingLiuliangEntity.getTimeString();
        long userNUmbers1 = t1.getUserNumbers();
        long  userNUmbers2 = advertisingLiuliangEntity.getUserNumbers();
        AdvertisingLiuliangEntity resultAdvertisingLiuliangEntity = new AdvertisingLiuliangEntity();
        resultAdvertisingLiuliangEntity.setAdverId(adverId);
        resultAdvertisingLiuliangEntity.setNumbers(nubmers+t1numbers);
        resultAdvertisingLiuliangEntity.setUserNumbers(userNUmbers1+userNUmbers2);
        resultAdvertisingLiuliangEntity.setTimeString(timeString);
        return resultAdvertisingLiuliangEntity;
    }
}
