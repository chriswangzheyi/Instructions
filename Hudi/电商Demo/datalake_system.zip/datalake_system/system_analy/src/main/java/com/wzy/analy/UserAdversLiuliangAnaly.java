package com.wzy.analy;

import com.wzy.entity.AdvertisingLiuliangEntity;
import com.wzy.entity.UserConpusEntity;
import com.wzy.map.AdvertisingLiuLiangMap;
import com.wzy.map.AdvertisingSecondLiuLiangMap;
import com.wzy.map.UserConpusMap;
import com.wzy.reduce.AdvertingLiuLiangReduce;
import com.wzy.reduce.AdvertingSecondLiuLiangReduce;
import com.wzy.reduce.UserConpusReduce;
import com.wzy.reduce.UserConpusTotalReduce;
import com.wzy.sink.AdversingLiuLiangTotallSink;
import com.wzy.sink.UserConpusTotallSink;
import com.wzy.sink.UserConpusUserDetailSink;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class UserAdversLiuliangAnaly {
    public static void main(String[] args) {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "192.168.37.137:9092");
        properties.setProperty("group.id", "youfan");
        //构建FlinkKafkaConsumer
        FlinkKafkaConsumer<String> myConsumer = new FlinkKafkaConsumer<String>("scanpage", new SimpleStringSchema(), properties);
        //        //指定偏移量
        myConsumer.setStartFromLatest();

        final DataStream<String> stream = env
                .addSource(myConsumer);

        env.enableCheckpointing(5000);
        DataStream<AdvertisingLiuliangEntity> map = stream.map(new AdvertisingLiuLiangMap());
        DataStream<AdvertisingLiuliangEntity> reduce = map.keyBy("groupField").timeWindowAll(Time.hours(1)).reduce(new AdvertingLiuLiangReduce());
        DataStream<AdvertisingLiuliangEntity> map2 = reduce.map(new AdvertisingSecondLiuLiangMap());
        DataStream<AdvertisingLiuliangEntity> totalReduce = map2.keyBy("groupField").timeWindowAll(Time.hours(1)).reduce(new AdvertingSecondLiuLiangReduce());
        totalReduce.addSink(new AdversingLiuLiangTotallSink());
        try {
            env.execute("UserAdversLiuliangAnaly");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
