package com.wzy.reduce;

import com.wzy.entity.AdvertisingLiuliangEntity;
import com.wzy.entity.LiuliangEntity;
import org.apache.flink.api.common.functions.ReduceFunction;

public class AdvertingLiuLiangReduce implements ReduceFunction<AdvertisingLiuliangEntity> {
    @Override
    public AdvertisingLiuliangEntity reduce(AdvertisingLiuliangEntity advertisingLiuliangEntity, AdvertisingLiuliangEntity t1) throws Exception {
        long userid = advertisingLiuliangEntity.getUserid();
        long adverId = advertisingLiuliangEntity.getAdverId();
        long nubmers = advertisingLiuliangEntity.getNumbers();
        long t1numbers = t1.getNumbers();
        String timeString = advertisingLiuliangEntity.getTimeString();
        AdvertisingLiuliangEntity resultAdvertisingLiuliangEntity = new AdvertisingLiuliangEntity();
        resultAdvertisingLiuliangEntity.setUserid(userid);
        resultAdvertisingLiuliangEntity.setAdverId(adverId);
        resultAdvertisingLiuliangEntity.setNumbers(nubmers+t1numbers);
        resultAdvertisingLiuliangEntity.setTimeString(timeString);
        return resultAdvertisingLiuliangEntity;
    }
}
