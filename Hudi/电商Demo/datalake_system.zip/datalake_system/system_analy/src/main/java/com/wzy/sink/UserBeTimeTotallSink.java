package com.wzy.sink;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.UserBehavEntity;
import com.wzy.util.ClickhouseUtils;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import java.util.HashMap;
import java.util.Map;

public class UserBeTimeTotallSink implements SinkFunction<UserBehavEntity> {

    @Override
    public void invoke(UserBehavEntity value) throws Exception {
        Map<String,Object> dataMap = new HashMap<String,Object>();
        String timeString = value.getTimeString();//
        long numbers = value.getNumbers();
        int timeinType = value.getTimeinType();
        dataMap.put("timeString",timeString);
        dataMap.put("timeinType",timeinType);
        dataMap.put("numbers",numbers);
        ClickhouseUtils.insertData(dataMap);
    }
}
