package com.wzy.map;

import com.alibaba.fastjson.JSONObject;
import com.wzy.entity.UserConpusEntity;
import com.wzy.input.Order;
import com.wzy.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.MapFunction;

public class UserConpusMap implements MapFunction<String, UserConpusEntity> {


    @Override
    public UserConpusEntity map(String s) throws Exception {
        if(StringUtils.isNotBlank(s)){
            Order youfanOrder = JSONObject.parseObject(s, Order.class);
            long userid = youfanOrder.getUserid();
            long createTime = youfanOrder.getCreateTime().getTime();
            String createTimeDay = DateUtil.tranferDate(createTime,"yyyyMMdd");
            long conpusId = youfanOrder.getCouponId();
            long numbers = 1l;
            String groupField = "userConpus=="+userid+"=="+conpusId+"=="+createTimeDay;

            UserConpusEntity userConpusEntity = new UserConpusEntity();
            userConpusEntity.setUserid(userid);
            userConpusEntity.setTimeinfo(createTime);
            userConpusEntity.setTimeString(createTimeDay);
            userConpusEntity.setConpusId(conpusId);
            userConpusEntity.setNumbers(numbers);
            userConpusEntity.setGroupField(groupField);
            return userConpusEntity;

        }
        return null;
    }
}
