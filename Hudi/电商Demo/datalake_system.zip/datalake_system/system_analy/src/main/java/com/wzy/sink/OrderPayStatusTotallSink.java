package com.wzy.sink;

import com.wzy.entity.LiuliangEntity;
import com.wzy.entity.OrderInfoEntity;
import com.wzy.util.ClickhouseUtils;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import java.util.HashMap;
import java.util.Map;

public class OrderPayStatusTotallSink implements SinkFunction<OrderInfoEntity> {

    @Override
    public void invoke(OrderInfoEntity value) throws Exception {
        Map<String,Object> dataMap = new HashMap<String,Object>();
        String timeString = value.getTimeString();//
        long numbers = value.getNumbers();
        int status = value.getStatus();
        dataMap.put("timeString",timeString);
        dataMap.put("status",status);
        dataMap.put("numbers",numbers);
        ClickhouseUtils.insertData(dataMap);
    }
}
