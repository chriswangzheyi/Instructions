package com.wzy.analy;

import com.wzy.entity.LiuliangEntity;
import com.wzy.map.LiuLiangMap;
import com.wzy.reduce.LiuLiangReduce;
import com.wzy.reduce.LiuLiangTotalReduce;
import com.wzy.sink.LiuLiangTotallSink;
import com.wzy.sink.LiuLiangUserDetailSink;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class LiuliangAnaly {
    public static void main(String[] args) {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "192.168.195.150:9092");
        properties.setProperty("group.id", "wzy");
        //构建FlinkKafkaConsumer
        FlinkKafkaConsumer<String> myConsumer = new FlinkKafkaConsumer<String>("scanpage", new SimpleStringSchema(), properties);
        //指定偏移量
        myConsumer.setStartFromLatest();

        final DataStream<String> stream = env.addSource(myConsumer);

        env.enableCheckpointing(5000);
        //自定义map
        DataStream<LiuliangEntity> map = stream.map(new LiuLiangMap());
        //自定义reduce,窗口时间5分钟
        DataStream<LiuliangEntity> reduce = map.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new LiuLiangReduce()); //按id做统计
        DataStream<LiuliangEntity> totalReduce = reduce.keyBy("groupField").timeWindowAll(Time.minutes(5)).reduce(new LiuLiangTotalReduce()); //做全量统计

        //添加sink做输出
        reduce.addSink(new LiuLiangUserDetailSink());
        totalReduce.addSink(new LiuLiangTotallSink());

        try {
            env.execute("LiuliangAnaly");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
