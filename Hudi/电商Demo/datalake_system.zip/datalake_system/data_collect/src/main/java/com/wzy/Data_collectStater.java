package com.wzy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Data_collectStater {

    public static void main(String[] args) {
        SpringApplication.run(Data_collectStater.class,args);
    }
}
