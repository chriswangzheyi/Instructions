package com.wzy.control;

import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("dataCollect")
public class DataCollectControl {

    @Autowired
    private KafkaTemplate kafkaTemplate;

    @RequestMapping(value = "collectData",method = RequestMethod.POST)
    public void collectData(@RequestBody String data){
        System.out.println(data);
        JSONObject jsonObject = JSONObject.parseObject(data);
        int logType = jsonObject.getInteger("logType");
        String topic = "";
        if(0==logType){
            topic = "scanpage";
        }
        kafkaTemplate.send(topic,data);

    }
}
