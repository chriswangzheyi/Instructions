package com.wzy.entity

case class WzyEntity(

  uid: Int,
  uname: String,
  dt: String

  )
