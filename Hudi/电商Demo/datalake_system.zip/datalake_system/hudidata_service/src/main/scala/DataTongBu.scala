import org.apache.hudi.config.HoodieIndexConfig
import org.apache.hudi.hive.MultiPartKeysValueExtractor
import org.apache.hudi.index.HoodieIndex
import org.apache.hudi.{DataSourceReadOptions, DataSourceWriteOptions}
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.{col, concat_ws, lit}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}

//将kafka中的数据同步到hudi中
object DataTongBu {

  def main(args: Array[String]): Unit = {
    System.setProperty("hadoop.home.dir", "E:\\worksoftinstall\\hadoop-2.7.5\\hadoop-2.7.5")
    import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
    import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe

    val conf = new SparkConf().set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    .setMaster("local[2]").setAppName("DataTongBu")

    //每5秒进行一次同步
    val streamingContext = new StreamingContext(conf, Seconds(5))
    val sparkSession = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()

    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> "192.168.195.150:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "use_a_separate_group_id_for_each_stream",
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )

    val topics = Array("test1")
    val stream = KafkaUtils.createDirectStream[String, String](
      streamingContext,
      PreferConsistent,
      Subscribe[String, String](topics, kafkaParams)
    )
    val dSteam = stream.map(p => p.value())
    dSteam.foreachRDD(rdd =>{
      val df = sparkSession.read.json(rdd)
      val isnull = rdd.isEmpty()
      print("空的吗=="+isnull)
      if(!isnull){
        try {
          val commitTime = System.currentTimeMillis().toString //生成提交时间
          val result = df.withColumn("ts", lit(commitTime)) //添加ts 时间戳列
            .withColumn("uuid", col("uid"))
            .withColumn("hudipart",  concat_ws("/", col("dt"), col("ds"))) //增加hudi分区列

          result.write.format("org.apache.hudi")
            .option("hoodie.insert.shuffle.parallelism", 2)
            .option("hoodie.upsert.shuffle.parallelism", 2)
            .option("PRECOMBINE_FIELD_OPT_KEY", "ts") //指定提交时间列
            .option("RECORDKEY_FIELD_OPT_KEY", "uuid") //指定uuid唯一标示列
            .option("hoodie.table.name", "wzysparkhudi6")
            .option("hoodie.datasource.write.partitionpath.field", "hudipart") //分区列
            .option(DataSourceWriteOptions.TABLE_TYPE_OPT_KEY, DataSourceWriteOptions.COW_TABLE_TYPE_OPT_VAL)
            .option(DataSourceWriteOptions.HIVE_URL_OPT_KEY, "jdbc:hive2://192.168.195.150:10000/default") //hiveserver2地址
            .option(DataSourceWriteOptions.HIVE_DATABASE_OPT_KEY, "default") //设置hudi与hive同步的数据库
            .option(DataSourceWriteOptions.HIVE_TABLE_OPT_KEY, "wzysparkhudi6") //设置hudi与hive同步的表名
            .option(DataSourceWriteOptions.HIVE_PARTITION_FIELDS_OPT_KEY, "dt,ds") //hive表同步的分区列
            .option(DataSourceWriteOptions.HIVE_PARTITION_EXTRACTOR_CLASS_OPT_KEY, classOf[MultiPartKeysValueExtractor].getName) // 分区提取器 按/ 提取分区
            .option(DataSourceWriteOptions.HIVE_SYNC_ENABLED_OPT_KEY, "true") //设置数据集注册并同步到hive
            .option(HoodieIndexConfig.BLOOM_INDEX_UPDATE_PARTITION_PATH, "true") //设置当分区变更时，当前数据的分区目录是否变更
            .option(HoodieIndexConfig.INDEX_TYPE_PROP, HoodieIndex.IndexType.GLOBAL_BLOOM.name()) //设置索引类型目前有HBASE,INMEMORY,BLOOM,GLOBAL_BLOOM 四种索引 为了保证分区变更后能找到必须设置全局GLOBAL_BLOOM
            .mode(SaveMode.Append)
            .save("/wzy/datahive6/wzysparkhudi")
        } catch {
          case ex: Exception => {
            ex.printStackTrace()
          } // 打印到标准err
          System.err.println("exception===>: ...")  // 打印到标准err

        }

      }

    });

    streamingContext.start()
    streamingContext.awaitTermination();

  }







}
