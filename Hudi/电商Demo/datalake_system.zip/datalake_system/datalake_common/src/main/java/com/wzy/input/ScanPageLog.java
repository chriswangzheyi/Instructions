package com.wzy.input;

/**
 * 页面浏览日志
 */
public class ScanPageLog extends Logparent{

    private long visitTime;//访问时间
    private long jumpTime;//跳出时间
    private long staytime;//停留时间
    private long productId;//商品id
    private long adverId;//广告id
    private long pingdaoId;//频道id
    private long productTypeId;//商品类别id
    private long huodongId;//活动id
    private  long miaoshaId;//秒杀活动id
    private  long tuangouId;//团购活动id
    private String pageId;//页面id

    public long getVisitTime() {
        return visitTime;
    }

    public void setVisitTime(long visitTime) {
        this.visitTime = visitTime;
    }

    public long getJumpTime() {
        return jumpTime;
    }

    public void setJumpTime(long jumpTime) {
        this.jumpTime = jumpTime;
    }

    public long getStaytime() {
        return staytime;
    }

    public void setStaytime(long staytime) {
        this.staytime = staytime;
    }

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public long getAdverId() {
        return adverId;
    }

    public void setAdverId(long adverId) {
        this.adverId = adverId;
    }

    public long getPingdaoId() {
        return pingdaoId;
    }

    public void setPingdaoId(long pingdaoId) {
        this.pingdaoId = pingdaoId;
    }

    public long getProductTypeId() {
        return productTypeId;
    }

    public void setProductTypeId(long productTypeId) {
        this.productTypeId = productTypeId;
    }

    public long getHuodongId() {
        return huodongId;
    }

    public void setHuodongId(long huodongId) {
        this.huodongId = huodongId;
    }

    public long getMiaoshaId() {
        return miaoshaId;
    }

    public void setMiaoshaId(long miaoshaId) {
        this.miaoshaId = miaoshaId;
    }

    public long getTuangouId() {
        return tuangouId;
    }

    public void setTuangouId(long tuangouId) {
        this.tuangouId = tuangouId;
    }

    public String getPageId() {
        return pageId;
    }

    public void setPageId(String pageId) {
        this.pageId = pageId;
    }
}
