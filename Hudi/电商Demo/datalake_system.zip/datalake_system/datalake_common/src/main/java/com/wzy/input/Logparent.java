package com.wzy.input;

//日志父类，部分公共类
public class Logparent {
    private long userid;//用户id
    private int divceType;//终端类型 0 pc端 1 app端 2 小程序端
    private int logType;//0 页面日志

    public long getUserid() {
        return userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }

    public int getDivceType() {
        return divceType;
    }

    public void setDivceType(int divceType) {
        this.divceType = divceType;
    }

    public int getLogType() {
        return logType;
    }

    public void setLogType(int logType) {
        this.logType = logType;
    }
}
