package com.wzy.util;

/**
 * 公用工具
 */
public class CommonUtils {

    public static Long getId(){
        return  DateUtil.getCurrentTime(1000);
    }
}
