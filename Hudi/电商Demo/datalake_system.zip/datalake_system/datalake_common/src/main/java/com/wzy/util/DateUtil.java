package com.wzy.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class DateUtil {

    public static String  tranferDate(long time,String dataForamt){
        DateFormat dateFormat = new SimpleDateFormat(dataForamt);
        Date date = new Date(time);
        return dateFormat.format(date);
    }

    public static Long getCurrentTime(Integer seed){
        Date date = new Date();
        Random random = new Random();
        int randomseed = 0;
        if(seed != null && seed > 0){
            randomseed = random.nextInt(seed);
        }
        return date.getTime()+randomseed;

    }



}
