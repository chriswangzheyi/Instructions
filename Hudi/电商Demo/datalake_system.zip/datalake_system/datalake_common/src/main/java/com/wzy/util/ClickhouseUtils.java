package com.wzy.util;

import com.alibaba.fastjson.JSONObject;

import java.util.Map;

public class ClickhouseUtils {

    public static void insertData(Map<String,Object> dataMap){
        System.out.println(JSONObject.toJSONString(dataMap));

    }
}
